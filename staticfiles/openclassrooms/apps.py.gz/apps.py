from django.apps import AppConfig


class OpenclassroomsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'openclassrooms'
